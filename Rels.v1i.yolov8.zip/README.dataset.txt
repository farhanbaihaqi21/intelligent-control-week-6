# foots > 2025-03-23 9:01pm
https://universe.roboflow.com/relll/foots-s8oqh-9s6ge

Provided by a Roboflow user
License: CC BY 4.0

